package touristsmanagementsystem;

import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.PreparedStatement;
import javax.swing.JFrame;

public class searchadvance extends javax.swing.JFrame {

    public int personalInfoId;
    public int selectedId;

    public searchadvance() {
        initComponents();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setSize(1600, 1000);
        populateTable();
        setPlaceholderText(jTextField1, "Enter any detail you want to search");
    }

    private void setPlaceholderText(JTextField textField, String placeholder) {
        textField.setText(placeholder);
        textField.setForeground(java.awt.Color.GRAY);

        textField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(java.awt.Color.BLACK);
                }
            }

            public void focusLost(FocusEvent evt) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(java.awt.Color.GRAY);
                    textField.setText(placeholder);
                }
            }
        });

    }

    private void refreshTable() {
        populateTable(); // Fetch the latest data from the database and update the table model
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        generatebill = new javax.swing.JButton();
        updatebookinginfo = new javax.swing.JButton();
        viewdetails = new javax.swing.JButton();
        deleteuser = new javax.swing.JButton();
        updatepersonalinfo = new javax.swing.JButton();
        deleteuser1 = new javax.swing.JButton();
        deleteuser2 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "FullName", "Gender", "Nationality", "Email", "Contact No", "Address", "PackageYesNo", "DepartureDate", "ReturnDate", "NoOfDaysStay", "NoOfTravelers", "RoomType", "FoodIncluded", "TotalPrice"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 92, 153));

        jPanel2.setBackground(new java.awt.Color(239, 255, 239));

        jPanel3.setBackground(new java.awt.Color(0, 92, 153));

        jPanel4.setBackground(new java.awt.Color(239, 255, 239));

        jPanel5.setBackground(new java.awt.Color(0, 92, 153));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture for n.JPG"))); // NOI18N

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        search.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        search.setText("Search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Search Hotels Here:");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "FullName", "Gender", "Nationality", "Email", "Contact No", "Address", "PackageYesNo", "DepartureDate", "ReturnDate", "NoOfDaysStay", "NoOfTravelers", "BookedTravellers", "RoomType", "FoodIncluded", "Description", "TotalPrice"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        generatebill.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        generatebill.setForeground(new java.awt.Color(0, 93, 153));
        generatebill.setText("GENERATE BILL");
        generatebill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generatebillActionPerformed(evt);
            }
        });

        updatebookinginfo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        updatebookinginfo.setForeground(new java.awt.Color(0, 93, 153));
        updatebookinginfo.setText("UPDATE BOOKING INFO ");
        updatebookinginfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebookinginfoActionPerformed(evt);
            }
        });

        viewdetails.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        viewdetails.setForeground(new java.awt.Color(0, 93, 153));
        viewdetails.setText("VIEW DETAILS");
        viewdetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewdetailsActionPerformed(evt);
            }
        });

        deleteuser.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        deleteuser.setForeground(new java.awt.Color(0, 93, 153));
        deleteuser.setText("DELETE USER");
        deleteuser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteuserActionPerformed(evt);
            }
        });

        updatepersonalinfo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        updatepersonalinfo.setForeground(new java.awt.Color(0, 93, 153));
        updatepersonalinfo.setText("UPDATE PERSONAL INFO ");
        updatepersonalinfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatepersonalinfoActionPerformed(evt);
            }
        });

        deleteuser1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        deleteuser1.setForeground(new java.awt.Color(0, 93, 153));
        deleteuser1.setText("REFRESH");
        deleteuser1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteuser1ActionPerformed(evt);
            }
        });

        deleteuser2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        deleteuser2.setForeground(new java.awt.Color(0, 93, 153));
        deleteuser2.setText("BACK");
        deleteuser2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteuser2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(deleteuser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(updatebookinginfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updatepersonalinfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(generatebill, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewdetails, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteuser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteuser2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(48, 48, 48)
                                .addComponent(search)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel2)
                        .addGap(27, 27, 27)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(viewdetails)
                        .addGap(18, 18, 18)
                        .addComponent(generatebill)
                        .addGap(18, 18, 18)
                        .addComponent(updatepersonalinfo)
                        .addGap(18, 18, 18)
                        .addComponent(updatebookinginfo)
                        .addGap(18, 18, 18)
                        .addComponent(deleteuser)
                        .addGap(18, 18, 18)
                        .addComponent(deleteuser1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(deleteuser2)))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void populateTable() {
        // Assuming you have established a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String username = "root";
        String password = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password); Statement statement = connection.createStatement()) {

            // Execute a query to retrieve data from both tables
            String query = "SELECT pi.id, pi.name, pi.gender, pi.nationality, pi.email, pi.contact, pi.address, bi.packageYES, bi.departuredate, bi.returndate, bi.numofdays, bi.numoftravelers,bi.bookedtravellers, bi.roomtype, bi.foodincluded,bi.description,  bi.totalprice "
                    + "FROM personal_info pi "
                    + "INNER JOIN booking_info bi ON pi.id= bi.id";
            ResultSet resultSet = statement.executeQuery(query);

            // Initialize the table model
            DefaultTableModel model = new DefaultTableModel();
            jTable2.setModel(model);

            // Set up the columns based on your database table structure
            model.addColumn("ID");
            model.addColumn("Full Name");
            model.addColumn("Gender");
            model.addColumn("Nationality");
            model.addColumn("Email");
            model.addColumn("Contact");
            model.addColumn("Address");
            model.addColumn("Package");
            model.addColumn("Departure Date");
            model.addColumn("Return Date");
            model.addColumn("No Of Days Stay");
            model.addColumn("No Of Travelers");
            model.addColumn("Bookedtravellers");
            model.addColumn("Room Type");
            model.addColumn("Food Included");
            model.addColumn("Description");
            model.addColumn("Total Price");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");

                model.addRow(new Object[]{
                    id,
                    resultSet.getString("name"),
                    resultSet.getString("gender"),
                    resultSet.getString("nationality"),
                    resultSet.getString("email"),
                    resultSet.getString("contact"),
                    resultSet.getString("address"),
                    resultSet.getString("packageYES"),
                    resultSet.getString("departuredate"),
                    resultSet.getString("returndate"),
                    resultSet.getString("numofdays"),
                    resultSet.getString("numoftravelers"),
                    resultSet.getString("bookedtravellers"),
                    resultSet.getString("roomtype"),
                    resultSet.getString("foodincluded"),
                    resultSet.getString("Description"),
                    resultSet.getString("totalprice"), //                viewDetailsButton // Add the button to the table cell
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getSelectedIdFromTable() {
        // Assuming you have a table named 'paymentTable'
        int selectedRow = jTable2.getSelectedRow(); // Get the selected row index

        if (selectedRow == -1) {
            // No row is selected, return a default value or handle the situation as needed
            return -1; // For example, you can return -1 to indicate no selection
        }
        // Assuming the ID is stored in the first column of the table
        selectedId = Integer.parseInt(jTable2.getValueAt(selectedRow, 0).toString());

        return selectedId;
    }

    private void viewDetailsButtonActionPerformed(int selectedId) {
        viewuserdetails viewDetailsForm = new viewuserdetails(this, selectedId);
        viewDetailsForm.setVisible(true);
    }

//    private void updateuserButtonActionPerformed(int selectedId) {
//        updateuserdetails viewDetailsForm = new updateuserdetails(this, selectedId);
//        viewDetailsForm.setVisible(true);
//    }
    private void generatebillButtonActionPerformed(int personalInfoId) {
        generatebill g = new generatebill(personalInfoId);
        g.setVisible(true);
    }

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
        String searchText = jTextField1.getText();
        if (searchText.isEmpty()) {
            populateTable(); // If no search text, populate the table with all data
            return;
        }

        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0); // Clear existing rows

        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String username = "root";
        String password = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password); Statement statement = connection.createStatement()) {

            String query = "SELECT pi.ID, pi.name, pi.gender, pi.nationality, pi.email, pi.contact, pi.address, bi.packageYES, bi.departuredate, bi.returndate, bi.numofdays, bi.numoftravelers,bi.bookedtravellers, bi.roomtype, bi.foodincluded,bi.description, bi.totalprice "
                    + "FROM personal_info pi "
                    + "INNER JOIN booking_info bi ON pi.ID = bi.id "
                    + "WHERE pi.name LIKE '%" + searchText + "%' "
                    + "OR pi.gender LIKE '%" + searchText + "%' "
                    + "OR pi.nationality LIKE '%" + searchText + "%' "
                    + "OR pi.email LIKE '%" + searchText + "%' "
                    + "OR pi.contact LIKE '%" + searchText + "%' "
                    + "OR pi.address LIKE '%" + searchText + "%' "
                    + "OR bi.packageYES LIKE '%" + searchText + "%' "
                    + "OR bi.departuredate LIKE '%" + searchText + "%' "
                    + "OR bi.returndate LIKE '%" + searchText + "%' "
                    + "OR bi.numofdays LIKE '%" + searchText + "%' "
                    + "OR bi.numoftravelers LIKE '%" + searchText + "%' "
                    + "OR bi.bookedtravellers LIKE '%" + searchText + "%' "
                    + "OR bi.roomtype LIKE '%" + searchText + "%' "
                    + "OR bi.foodincluded LIKE '%" + searchText + "%' "
                    + "OR bi.description LIKE '%" + searchText + "%' "
                    + "OR bi.totalprice LIKE '%" + searchText + "%'";

            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getInt("ID"),
                    resultSet.getString("name"),
                    resultSet.getString("gender"),
                    resultSet.getString("nationality"),
                    resultSet.getString("email"),
                    resultSet.getString("contact"),
                    resultSet.getString("address"),
                    resultSet.getString("packageYES"),
                    resultSet.getString("departuredate"),
                    resultSet.getString("returndate"),
                    resultSet.getString("numofdays"),
                    resultSet.getString("numoftravelers"),
                    resultSet.getString("bookedtravellers"),
                    resultSet.getString("roomtype"),
                    resultSet.getString("foodincluded"),
                    resultSet.getString("description"),
                    resultSet.getString("totalprice")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
//
    }//GEN-LAST:event_searchActionPerformed

    private void generatebillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generatebillActionPerformed
        // TODO add your handling code here:
        generatebill.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedId = getSelectedIdFromTable(); // Get the selected ID
                if (selectedId != -1) {
                    generatebillButtonActionPerformed(selectedId);
                }
            }
        });
    }//GEN-LAST:event_generatebillActionPerformed

    private void viewdetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewdetailsActionPerformed
        viewdetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedId = getSelectedIdFromTable(); // Get the selected ID
                if (selectedId != -1) {
                    viewDetailsButtonActionPerformed(selectedId);
                }
            }
        });
    }//GEN-LAST:event_viewdetailsActionPerformed

    private void updatebookinginfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebookinginfoActionPerformed

        int selectedRow = jTable2.getSelectedRow();
        if (selectedRow != -1) {
            // Get the selected row's data
            Object[] rowData = new Object[jTable2.getColumnCount()];
            for (int column = 0; column < jTable2.getColumnCount(); column++) {
                rowData[column] = jTable2.getValueAt(selectedRow, column);
            }
// TODO add your handling code here:
            personalInfoId = Integer.parseInt(rowData[0].toString());
//         Create an instance of the bookinginfo form with the personalInfoId
            Booking_Info bookingInfoForm = new Booking_Info(personalInfoId);

            // Populate the bookinginfo form with data from the selected row
            bookingInfoForm.populateFields(rowData);
            // Show the forms
            bookingInfoForm.showUpdateButton();
            bookingInfoForm.setVisible(true);
            refreshTable();

        }
    }//GEN-LAST:event_updatebookinginfoActionPerformed

    private void deleteuserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteuserActionPerformed
// Get the selected row index
        int selectedRow = jTable2.getSelectedRow();

        // Check if a row is selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Delete Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the ID of the selected row (assuming it's stored in the first column)
        int selectedId = Integer.parseInt(jTable2.getValueAt(selectedRow, 0).toString());

        // Delete the row from the database table
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String username = "root";
        String password = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            // Start a transaction
            connection.setAutoCommit(false);

            // Delete from the "booking_info" table
            String deleteBookingInfoQuery = "DELETE FROM booking_info WHERE id = ?";
            PreparedStatement bookingInfoStatement = connection.prepareStatement(deleteBookingInfoQuery);
            bookingInfoStatement.setInt(1, selectedId);
            bookingInfoStatement.executeUpdate();

            // Delete from the "personal_info" table
            String deletePersonalInfoQuery = "DELETE FROM personal_info WHERE id = ?";
            PreparedStatement personalInfoStatement = connection.prepareStatement(deletePersonalInfoQuery);
            personalInfoStatement.setInt(1, selectedId);
            personalInfoStatement.executeUpdate();

            // Commit the transaction
            connection.commit();

            // Delete the row from the jTable2
            DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
            model.removeRow(selectedRow);

            JOptionPane.showMessageDialog(this, "Row deleted successfully.", "Delete Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTable();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting row.", "Delete Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_deleteuserActionPerformed

    private void updatepersonalinfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatepersonalinfoActionPerformed

        // TODO add your handling code here:
        int selectedRow = jTable2.getSelectedRow();
        if (selectedRow != -1) {
            // Get the selected row's data
            Object[] rowData = new Object[jTable2.getColumnCount()];
            for (int column = 0; column < jTable2.getColumnCount(); column++) {
                rowData[column] = jTable2.getValueAt(selectedRow, column);
            }

            // Get the personalInfoId from the selected row (assuming it's in the first column)
            personalInfoId = Integer.parseInt(rowData[0].toString());

            // Create an instance of the personalinfo form with the personalInfoId
            Personal_Info personalInfoForm = new Personal_Info();
//
//            // Populate the personalinfo form with data from the selected row
            personalInfoForm.populateFields(rowData);
            personalInfoForm.showUpdateButton();
            personalInfoForm.setVisible(true);
            refreshTable();

        }

    }//GEN-LAST:event_updatepersonalinfoActionPerformed

    private void deleteuser1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteuser1ActionPerformed
        // TODO add your handling code here:
        refreshTable();
    }//GEN-LAST:event_deleteuser1ActionPerformed

    private void deleteuser2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteuser2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_deleteuser2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(searchadvance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(searchadvance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(searchadvance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(searchadvance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                searchadvance paymentForm = new searchadvance(); // Create an instance of Payment form
                paymentForm.setVisible(true); // Show the Payment form

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton deleteuser;
    private javax.swing.JButton deleteuser1;
    private javax.swing.JButton deleteuser2;
    private javax.swing.JButton generatebill;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton search;
    private javax.swing.JButton updatebookinginfo;
    private javax.swing.JButton updatepersonalinfo;
    private javax.swing.JButton viewdetails;
    // End of variables declaration//GEN-END:variables
}
