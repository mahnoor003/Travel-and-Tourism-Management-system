package touristsmanagementsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

public class viewnewpackages extends javax.swing.JFrame {

    private int personalInfoId;
    private String packageYES = "Yes";

    public viewnewpackages(int personalInfoId) {
        this.personalInfoId = personalInfoId;
        initComponents();
        update.setVisible(false);
        delete.setVisible(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        populateTable();
        update.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected row index
                int selectedRow = jTable1.getSelectedRow();

                // Check if a row is selected
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to update.", "Update Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the selected ID from the JTable (assuming it's in the first column)
                int selectedId;
                selectedId = Integer.parseInt(jTable1.getValueAt(selectedRow, 0).toString());
                addnewpackages a = new addnewpackages();
                a.setVisible(true);
            }
        });

    }

    private void populateTable() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String dbUsername = "root";
        String dbPassword = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword); Statement statement = connection.createStatement()) {

            String query = "SELECT * FROM packages";
            ResultSet resultSet = statement.executeQuery(query);

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0); // Clear existing rows

            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getInt("ID"),
                    resultSet.getString("DepartureDate"),
                    resultSet.getString("ReturnDate"),
                    resultSet.getInt("NoOfDaysStay"),
                    resultSet.getInt("NoOfTravellers"),
                    resultSet.getInt("bookedtravellers"),
                    resultSet.getString("RoomType"),
                    resultSet.getString("FoodIncluded"),
                    resultSet.getString("Description"),
                    resultSet.getDouble("totalprice")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void updateBooking(int packageId) {
        // Retrieve the existing booking information
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String dbUsername = "root";
        String dbPassword = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword); Statement statement = connection.createStatement()) {

            // Query to retrieve the existing booking information based on packageId
            String selectQuery = "SELECT * FROM packages WHERE ID = " + packageId;
            ResultSet selectResult = statement.executeQuery(selectQuery);

            if (selectResult.next()) {
                // Extract the existing booking details
                String departureDate = selectResult.getString("DepartureDate");
                String returnDate = selectResult.getString("ReturnDate");
                int numOfDays = selectResult.getInt("NoOfDaysStay");
                int numOfTravelers = selectResult.getInt("NoOfTravellers");
                String roomType = selectResult.getString("RoomType");
                boolean foodIncluded = selectResult.getBoolean("FoodIncluded");
                String description = selectResult.getString("Description");
                double totalPrice = selectResult.getDouble("TotalPrice");

                // You can now update the booking information based on user input
                // For example, you can show input dialogs to update specific fields
                String updatedDepartureDate = JOptionPane.showInputDialog(this, "Enter updated departure date:", departureDate);
                String updatedReturnDate = JOptionPane.showInputDialog(this, "Enter updated return date:", returnDate);
                // Repeat this for other fields you want to update

                // Update the database with the new values
                String updateQuery = "UPDATE packages SET DepartureDate = ?, ReturnDate = ?, NoOfDaysStay = ?, NoOfTravellers = ?, RoomType = ?, FoodIncluded = ?, Description = ?, TotalPrice = ? WHERE ID = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setString(1, updatedDepartureDate);
                updateStatement.setString(2, updatedReturnDate);
                updateStatement.setInt(3, numOfDays); // Update other fields as needed
                updateStatement.setInt(4, numOfTravelers);
                updateStatement.setString(5, roomType);
                updateStatement.setBoolean(6, foodIncluded);
                updateStatement.setString(7, description);
                updateStatement.setDouble(8, totalPrice);
                updateStatement.setInt(9, packageId);

                updateStatement.executeUpdate();

                JOptionPane.showMessageDialog(this, "Booking information updated successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Booking not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating booking information.", "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        jSpinner1 = new javax.swing.JSpinner();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        booknow = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        update = new javax.swing.JButton();
        update1 = new javax.swing.JButton();

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 93, 153));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ADD PACKAGES");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 93, 153));
        jLabel10.setText("  Add Packages");

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 93, 153));
        jLabel24.setText(" View Packages");
        jLabel24.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 93, 153), 5, true));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture final personalinfo.JPG"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Captureeifo.JPG"))); // NOI18N
        jLabel25.setText("jLabel25");

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture forward.JPG"))); // NOI18N
        jLabel30.setText("jLabel25");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(131, 131, 131))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69)))
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel25))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addContainerGap(11, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel30)
                .addGap(32, 32, 32))
        );

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Captureynrb.JPG"))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "DepartureDate", "ReturnDate", "NoOfDaysStay", "NoOfTravellers", "BookedTravellers", "RoomType", "FoodIncluded", "Description", "TotalPrice"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        booknow.setBackground(new java.awt.Color(0, 93, 153));
        booknow.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booknow.setForeground(new java.awt.Color(255, 255, 255));
        booknow.setText("BOOK NOW ");
        booknow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booknowActionPerformed(evt);
            }
        });

        delete.setBackground(new java.awt.Color(0, 93, 153));
        delete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 255, 255));
        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(0, 93, 153));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("REFRESH");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(0, 93, 153));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("BACK");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        update.setBackground(new java.awt.Color(0, 93, 153));
        update.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        update.setForeground(new java.awt.Color(255, 255, 255));
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        update1.setBackground(new java.awt.Color(0, 93, 153));
        update1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        update1.setForeground(new java.awt.Color(255, 255, 255));
        update1.setText("GENERATE BILL");
        update1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(booknow, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(update1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 874, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(258, 258, 258))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booknow)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(update1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update)
                    .addComponent(delete))
                .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void booknowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booknowActionPerformed

        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow >= 0) {
            int selectedId = (int) jTable1.getValueAt(selectedRow, 0);
            handleBooking(selectedId);
        } else {
            JOptionPane.showMessageDialog(viewnewpackages.this, "Please select a package to book.");
        }

    }//GEN-LAST:event_booknowActionPerformed

    private void handleBooking(int selectedId) {
        String travelersInput = JOptionPane.showInputDialog(this, "Enter the number of travelers:");
        if (travelersInput != null && !travelersInput.isEmpty()) {
            int travelers = Integer.parseInt(travelersInput);

            String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
            String dbUsername = "root";
            String dbPassword = "Mahanoor@2003";

            try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword); PreparedStatement selectStatement = connection.prepareStatement("SELECT * FROM packages WHERE ID = ?"); PreparedStatement updateStatement = connection.prepareStatement("UPDATE packages SET bookedtravellers = bookedtravellers + ? WHERE ID = ?"); PreparedStatement insertStatement = connection.prepareStatement("INSERT INTO booking_info (ID, packageYES, DepartureDate, ReturnDate, NumOfDays, NumOfTravelers, BookedTravellers, RoomType, FoodIncluded, Description, TotalPrice) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {

                selectStatement.setInt(1, selectedId);
                ResultSet selectResult = selectStatement.executeQuery();
                if (selectResult.next()) {
                    int totalLimit = selectResult.getInt("NoOfTravellers");
                    int currentTravellers = selectResult.getInt("bookedtravellers");
                    String departureDate = selectResult.getString("DepartureDate");
                    String returnDate = selectResult.getString("ReturnDate");
                    int numOfDays = selectResult.getInt("NoOfDaysStay");
                    String roomType = selectResult.getString("RoomType");
                    String foodIncluded = selectResult.getString("FoodIncluded");
                    String description = selectResult.getString("Description");
                    double totalPrice = selectResult.getDouble("TotalPrice");

                    if (currentTravellers + travelers <= totalLimit) {
                        updateStatement.setInt(1, travelers);
                        updateStatement.setInt(2, selectedId);
                        updateStatement.executeUpdate();

                        insertStatement.setInt(1, personalInfoId);
                        insertStatement.setString(2, "Yes"); // Assuming "packageYES" is a String column
                        insertStatement.setString(3, departureDate);
                        insertStatement.setString(4, returnDate);
                        insertStatement.setInt(5, numOfDays);
                        insertStatement.setInt(6, totalLimit);
                        insertStatement.setInt(7, currentTravellers + travelers);
                        insertStatement.setString(8, roomType);
                        insertStatement.setString(9, foodIncluded);
                        insertStatement.setString(10, description);
                        insertStatement.setDouble(11, totalPrice);

                        insertStatement.executeUpdate();

                        JOptionPane.showMessageDialog(this, "Booking successful for " + travelers + " travelers.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Booking limit exceeded for this package.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Package not found.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error handling booking.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed

// Get the selected row index
        int selectedRow = jTable1.getSelectedRow();

        // Check if a row is selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Delete Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the ID of the selected row (assuming it's stored in the first column)
        int selectedId = Integer.parseInt(jTable1.getValueAt(selectedRow, 0).toString());

        // Delete the row from the database table
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";
        String username = "root";
        String password = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            // Start a transaction
            connection.setAutoCommit(false);

            // Delete from the "booking_info" table
            String deleteBookingInfoQuery = "DELETE FROM packages WHERE id = ?";
            PreparedStatement bookingInfoStatement = connection.prepareStatement(deleteBookingInfoQuery);
            bookingInfoStatement.setInt(1, selectedId);
            bookingInfoStatement.executeUpdate();

            // Commit the transaction
            connection.commit();

            // Delete the row from the jTable2
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.removeRow(selectedRow);

            JOptionPane.showMessageDialog(this, "Package deleted successfully.", "Delete Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting row.", "Delete Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_deleteActionPerformed

    private void refreshTable() {
        populateTable(); // Fetch the latest data from the database and update the table model
    }
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        refreshTable();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed

        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) {
            // Get the selected row's data
            Object[] rowData = new Object[jTable1.getColumnCount()];
            for (int column = 0; column < jTable1.getColumnCount(); column++) {
                rowData[column] = jTable1.getValueAt(selectedRow, column);
            }
// TODO add your handling code here:
            int packageId = Integer.parseInt(rowData[0].toString());
//         Create an instance of the bookinginfo form with the personalInfoId
            addnewpackages bookingInfoForm = new addnewpackages();

            // Populate the bookinginfo form with data from the selected row
            bookingInfoForm.populateFields(rowData);
            // Show the forms
//bookingInfoForm.showUpdateButton();

            bookingInfoForm.setVisible(true);
            bookingInfoForm.showUpdateButton();
            refreshTable();

        }


    }//GEN-LAST:event_updateActionPerformed

    private void update1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update1ActionPerformed
        // TODO add your handling code here:
        generatebill g = new generatebill(personalInfoId);
        g.setVisible(true);
    }//GEN-LAST:event_update1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewnewpackages.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewnewpackages.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewnewpackages.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewnewpackages.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int personalInfoId = savePersonalInfo();
                viewnewpackages bookingForm = new viewnewpackages(personalInfoId);
                bookingForm.setVisible(true);
            }

            private int savePersonalInfo() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton booknow;
    private javax.swing.JButton delete;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton update;
    private javax.swing.JButton update1;
    // End of variables declaration//GEN-END:variables
}
