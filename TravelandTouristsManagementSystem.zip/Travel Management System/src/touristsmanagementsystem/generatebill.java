package touristsmanagementsystem;

import java.io.FileOutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Desktop;
import java.io.File;
import javax.swing.JFrame;

public class generatebill extends javax.swing.JFrame {

    private int personalInfoId;

    public generatebill(int personalInfoId) {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.personalInfoId = personalInfoId;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        generatebill = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        generatebill1 = new javax.swing.JButton();

        jLabel5.setText("jLabel5");

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 93, 153));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ADD DETAILS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel2)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(185, 185, 193));
        jLabel10.setText("BOOKING INFO");

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Captureynrb.JPG"))); // NOI18N

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 93, 153));
        jLabel24.setText("  Generate Bill");
        jLabel24.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 93, 153), 5, true));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/logo.JPG"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture forward.JPG"))); // NOI18N
        jLabel25.setText("jLabel25");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(185, 185, 193));
        jLabel15.setText("Personal Info");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Captureinfo.JPG"))); // NOI18N
        jLabel1.setText("jLabel1");

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture bbook.JPG"))); // NOI18N
        jLabel18.setText("jLabel18");

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture forward.JPG"))); // NOI18N
        jLabel26.setText("jLabel25");

        generatebill.setBackground(new java.awt.Color(0, 93, 153));
        generatebill.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        generatebill.setForeground(new java.awt.Color(255, 255, 255));
        generatebill.setText("GENERATE BILL");
        generatebill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generatebillActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 93, 153));
        jLabel4.setText("Generate your bill here !!");

        generatebill1.setBackground(new java.awt.Color(0, 93, 153));
        generatebill1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        generatebill1.setForeground(new java.awt.Color(255, 255, 255));
        generatebill1.setText("BACK");
        generatebill1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generatebill1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(299, 299, 299))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(91, 91, 91)
                            .addComponent(jLabel10)
                            .addGap(117, 117, 117)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(83, 83, 83)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(87, 87, 87)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(187, 187, 187)))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(generatebill, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(333, 333, 333))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(generatebill1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(405, 405, 405))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                .addGap(556, 556, 556))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel25))
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jLabel26)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(130, 130, 130)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(generatebill, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(112, 112, 112)
                .addComponent(generatebill1)
                .addGap(79, 79, 79))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void generatebillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generatebillActionPerformed
        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem?useSSL=false";
        String username = "root";
        String password = "Mahanoor@2003";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password); Statement statement = connection.createStatement()) {

            // Query to retrieve personal and booking information based on personalInfoId
            String query = "SELECT * FROM personal_info p JOIN booking_info b ON p.id = b.id WHERE p.id = " + personalInfoId;
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                String fullName = resultSet.getString("name");
                String gender = resultSet.getString("gender");
                String nationality = resultSet.getString("nationality");
                String email = resultSet.getString("email");
                String contactNo = resultSet.getString("contact");
                String address = resultSet.getString("address");
                String packageYesNo = resultSet.getString("packageYES");
                String departureDate = resultSet.getString("departuredate");
                String returnDate = resultSet.getString("returndate");
                int noOfDaysStay = resultSet.getInt("numofdays");
                int noOfTravelers = resultSet.getInt("numoftravelers");
                int bookedtravellers = resultSet.getInt("bookedtravellers");
                String roomType = resultSet.getString("roomtype");
                String foodIncluded = resultSet.getString("foodincluded");
                String description = resultSet.getString("description");
                double totalPrice = resultSet.getDouble("totalprice");

                String directoryPath = "C:\\Users\\USER\\Downloads\\pdf";
                File directory = new File(directoryPath);

                if (!directory.exists()) {
                    directory.mkdirs();
                }

                String fileName = "receipt_" + personalInfoId + ".pdf";
                String receiptFilePath = directoryPath + File.separator + fileName;

                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(receiptFilePath));
                document.open();

                // Add receipt content
                document.add(new Paragraph("============================================================="));
                document.add(new Paragraph("--------------- DREAM WORLD JOURNEY - RECIEPT ---------------"));
                document.add(new Paragraph("=============================================================\n"));
                document.add(new Paragraph("\n---------- Customer Information ----------\n"));
                document.add(new Paragraph("Name: " + fullName));
                document.add(new Paragraph("Gender: " + gender));
                document.add(new Paragraph("Nationality: " + nationality));
                document.add(new Paragraph("Email: " + email));
                document.add(new Paragraph("Contact No: " + contactNo));
                document.add(new Paragraph("Address: " + address));
                document.add(new Paragraph("\n---------- Booking Details ----------\n"));
                document.add(new Paragraph("Package Availed: " + packageYesNo));
                document.add(new Paragraph("Departure Date: " + departureDate));
                document.add(new Paragraph("Return Date: " + returnDate));
                document.add(new Paragraph("No. of Days Stay: " + noOfDaysStay));
                document.add(new Paragraph("No. of booked travellers: " + bookedtravellers));
                document.add(new Paragraph("No. of Travelers: " + noOfTravelers));
                document.add(new Paragraph("Room Type: " + roomType));
                document.add(new Paragraph("Food Included: " + foodIncluded));
                document.add(new Paragraph("Description: " + description));
                document.add(new Paragraph("\n---------- Payment Details ----------\n"));
                document.add(new Paragraph("Total Price: " + totalPrice + " PKR"));
                document.add(new Paragraph("Payment Method: Cash On Payment\n"));
                document.add(new Paragraph("\n-------------------------------------\n"));
                document.add(new Paragraph("Thank you for choosing Dream World Journey!"));
                document.add(new Paragraph("For any inquiries, contact our customer support.\n"));

                document.add(new Paragraph("Email: info@dreamworldjourney.com"));
                document.add(new Paragraph("Phone: +1 (800) 123-4567"));
                document.add(new Paragraph("\n============================================================="));
                document.close();
                File pdfFile = new File(receiptFilePath);
                if (pdfFile.exists()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    System.out.println("PDF file not found: " + receiptFilePath);
                }
            } else {
                System.out.println("No data found for personalInfoId: " + personalInfoId);
            }
        } catch (SQLException | DocumentException | FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }// TODO add your handling code here:

    }//GEN-LAST:event_generatebillActionPerformed

    private void generatebill1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generatebill1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_generatebill1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(generatebill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(generatebill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(generatebill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(generatebill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Personal_Info personalInfo = new Personal_Info();
                int personalInfoId = personalInfo.savePersonalInfo();

                // Create the receipt form with the obtained personalInfoId
                generatebill receiptForm = new generatebill(personalInfoId);
                receiptForm.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton generatebill;
    private javax.swing.JButton generatebill1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
