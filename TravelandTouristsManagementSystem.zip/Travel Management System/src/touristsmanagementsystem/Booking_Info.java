package touristsmanagementsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JFrame;

public class Booking_Info extends javax.swing.JFrame {

    private int SelectedId;
    private int tourPrice = 1000;
    private int personalInfoId;
    private String Packagename;
    private int bookedtravellers = 0;
    private String description = "None";
    String numberPattern = "^\\d+$";
    String datePattern = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$";
    int travelers;

    public Booking_Info(int personalInfoId) {
        this.personalInfoId = personalInfoId;
        initComponents();

        update.setVisible(false);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setPlaceholderText(depart, "Enter Departure date");
        setPlaceholderText(returndate, "Enter Return date");
        setPlaceholderText(nooftravellers, "Enter Members");

        depart.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {

                calculateTotalPrice();
            }
        });

        returndate.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {

                calculateTotalPrice();
            }
        });

        // Add listeners to relevant fields for automatic calculation of total price
        nooftravellers.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

                calculateTotalPrice();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {

                calculateTotalPrice();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {

                calculateTotalPrice();
            }
        });

        jRadioButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton3.isSelected()) {
                    jRadioButton4.setSelected(false);
                }
                viewnewpackages v = new viewnewpackages(personalInfoId);
                v.setVisible(true);
            }
        });
        jRadioButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton4.isSelected()) {
                    jRadioButton3.setSelected(false);
                }
                calculateTotalPrice();
                Packagename = "no package";
            }
        });

        jRadioButton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton7.isSelected()) {
                    jRadioButton8.setSelected(false);
                }
                calculateTotalPrice();
            }
        });
        jRadioButton8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton8.isSelected()) {
                    jRadioButton7.setSelected(false);
                }
                calculateTotalPrice();
            }
        });

        jRadioButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton5.isSelected()) {
                    jRadioButton6.setSelected(false);
                }
                calculateTotalPrice();
            }
        });

        jRadioButton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jRadioButton6.isSelected()) {
                    jRadioButton5.setSelected(false);
                }
                calculateTotalPrice();
            }
        });
    }

    public void populateFields(Object[] data) {
        // Assuming you have text fields named jTextField1, jTextField2, etc.
        SelectedId = (int) data[0];
        String packageValue = data[7].toString(); // Get package value from data

        if (packageValue.equals("yes")) {
            jRadioButton3.setSelected(true); // Select "yes" radio button for package
        } else if (packageValue.equals("no")) {
            jRadioButton4.setSelected(true); // Select "no" radio button for package
        }

        depart.setText(data[8].toString()); // Set departure date
        returndate.setText(data[9].toString()); // Set return date

        nooftravellers.setText(data[11].toString()); // Set number of travelers

        String roomTypeValue = data[13].toString(); // Get room type value from data

        if (roomTypeValue.equals("ac")) {
            jRadioButton7.setSelected(true); // Select "ac" radio button for room type
        } else if (roomTypeValue.equals("non ac")) {
            jRadioButton8.setSelected(true); // Select "non ac" radio button for room type
        }

        String foodIncludedValue = data[14].toString(); // Get food included value from data

        if (foodIncludedValue.equals("yes")) {
            jRadioButton5.setSelected(true); // Select "yes" radio button for food included
        } else if (foodIncludedValue.equals("no")) {
            jRadioButton6.setSelected(true); // Select "no" radio button for food included
        }

        // Assuming you have labels named jLabel5 and jLabel10 for "no of days stay" and "total price"
        jLabel23.setText(data[10].toString()); // Set the "no of days stay" label
        jLabel21.setText(data[16].toString()); // Set the "total price" label
    }

    private boolean validateNumberOfTravellers(String travellers, String numberPattern) {

        //int nooftravellersValue;
        try {
            travelers = Integer.parseInt(nooftravellers.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number of travelers entered. Please use numbers.", "Traveler Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean validateDepartureDate(String depart) {
        if (!depart.matches(datePattern)) {
            return false;
        }
        return true;
    }

    private boolean validateReturnDate(String returndate) {
        if (!returndate.matches(datePattern)) {
            return false;
        }
        return true;
    }

    private void setPlaceholderText(JTextField textField, String placeholder) {
        textField.setText(placeholder);
        textField.setForeground(java.awt.Color.GRAY);

        textField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(java.awt.Color.BLACK);
                }
            }

            public void focusLost(FocusEvent evt) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(java.awt.Color.GRAY);
                    textField.setText(placeholder);
                }
            }
        });
    }

    private void calculateTotalPrice() {
        String travelersText = nooftravellers.getText();
        if (travelersText.isEmpty()) {
            jLabel21.setText("");
            return; // Exit the method if travelers text is empty
        }

//        int numTravelers = Integer.parseInt(travelersText);
        int numTravelers = 0; // Initialize to a default value
        try {
            numTravelers = Integer.parseInt(travelersText);
        } catch (NumberFormatException e) {
            // Handle the case where travelersText is not a valid integer
            jLabel21.setText("");
            return;
        }

        String departureText = depart.getText();
        String returnText = returndate.getText();

        if (departureText.isEmpty() || returnText.isEmpty()) {
            jLabel23.setText(""); // Clear the label if dates are not entered
            jLabel21.setText("");
            return;
        }

        LocalDate departureDate = LocalDate.parse(departureText, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        LocalDate returnDate = LocalDate.parse(returnText, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int numDays = (int) ChronoUnit.DAYS.between(departureDate, returnDate);
        jLabel23.setText("" + numDays); // Set the number of days label

        int roomTypePrice = 0;
        if (jRadioButton7.isSelected()) { // AC room type selected
            roomTypePrice = 2000;
        } else if (jRadioButton8.isSelected()) { // Non-AC room type selected
            roomTypePrice = 1000;
        }

        int foodIncludedPrice = jRadioButton5.isSelected() ? 1000 : 0;

        int totalPrice = (tourPrice + roomTypePrice + foodIncludedPrice) * (numTravelers * numDays);
        jLabel21.setText("" + totalPrice);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        depart = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        returndate = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        nooftravellers = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jLabel23 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        add1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 93, 153));
        jLabel5.setText("No Of Days Stay");

        jPanel10.setBackground(new java.awt.Color(0, 93, 153));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("BOOKING INFORMATION");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel26)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 93, 153));
        jLabel16.setText("Departure Date & Time");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 93, 153));
        jLabel8.setText("Return Date & Time");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 93, 153));
        jLabel18.setText("No Of Travellers");

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 93, 153));
        jLabel19.setText("Food Included");

        jRadioButton5.setText("Yes");

        jRadioButton6.setText("No");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 93, 153));
        jLabel20.setText("Total Price");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 93, 153));
        jLabel22.setText("Room Type");

        jRadioButton7.setText("AC");
        jRadioButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton7ActionPerformed(evt);
            }
        });

        jRadioButton8.setText("Non - AC");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        add1.setBackground(new java.awt.Color(0, 93, 153));
        add1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        add1.setForeground(new java.awt.Color(255, 255, 255));
        add1.setText("ADD");
        add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add1ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(0, 93, 153));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("NEXT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        update.setBackground(new java.awt.Color(0, 93, 153));
        update.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        update.setForeground(new java.awt.Color(255, 255, 255));
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(add1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add1)
                    .addComponent(jButton1)
                    .addComponent(update))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 93, 153));
        jLabel29.setText("Do you want to take any Package?");

        jRadioButton3.setText("Yes");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        jRadioButton4.setText("No");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel22)
                            .addComponent(jLabel5)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(131, 131, 131)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jRadioButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(returndate, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton3)
                                    .addComponent(depart, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(nooftravellers, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel7Layout.createSequentialGroup()
                                    .addComponent(jRadioButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jRadioButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jRadioButton4)
                        .addGap(175, 175, 175)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jRadioButton3)
                    .addComponent(jRadioButton4))
                .addGap(25, 25, 25)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(depart, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addGap(19, 19, 19)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(returndate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addComponent(nooftravellers, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jRadioButton7)
                    .addComponent(jRadioButton8))
                .addGap(29, 29, 29)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jRadioButton5)
                    .addComponent(jRadioButton6))
                .addGap(19, 19, 19)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(232, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 93, 153));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ADD DETAILS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel2)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 93, 153));
        jLabel10.setText("  BOOKING INFO");
        jLabel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 93, 153), 5, true));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(185, 185, 193));
        jLabel24.setText("PERSONAL INFO");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture final personalinfo.JPG"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Captureeifo.JPG"))); // NOI18N
        jLabel25.setText("jLabel25");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Captureinfo.JPG"))); // NOI18N
        jLabel6.setText("jLabel1");

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(185, 185, 193));
        jLabel27.setText("GENERATE BILL");

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture forward.JPG"))); // NOI18N
        jLabel30.setText("jLabel25");

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/touristsmanagementsystem/Capture forward.JPG"))); // NOI18N
        jLabel28.setText("jLabel25");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel24)
                        .addGap(59, 59, 59)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(94, 94, 94)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(103, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel25)
                                .addGap(9, 9, 9)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel10))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(24, 24, 24))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel30))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Captureynrb.JPG"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton7ActionPerformed

    private void add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add1ActionPerformed
        validatedetails();
        saveBookingInfo();

    }//GEN-LAST:event_add1ActionPerformed

    private void saveBookingInfo() {
        String packageYesNo = jRadioButton3.isSelected() ? "yes" : "no";
        String departureDate = depart.getText();
        String returnDate = returndate.getText();
        int daysStay = Integer.parseInt(jLabel23.getText());
        travelers = Integer.parseInt(nooftravellers.getText());
        String roomType = jRadioButton7.isSelected() ? "ac" : "non ac";
        String foodIncluded = jRadioButton5.isSelected() ? "yes" : "no";
        double totalPrice = Double.parseDouble(jLabel21.getText());

        validatedetails();

        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";

        String username = "root";
        String password = "Mahanoor@2003";

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            String query = "INSERT INTO booking_info (ID, packageYES, departuredate, returndate, numofdays, numoftravelers,bookedtravellers, roomtype, foodincluded,description, totalprice) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, personalInfoId);
            preparedStatement.setString(2, packageYesNo);
            preparedStatement.setString(3, departureDate);
            preparedStatement.setString(4, returnDate);
            preparedStatement.setInt(5, daysStay);
            preparedStatement.setInt(6, travelers);
            preparedStatement.setInt(7, bookedtravellers);
            preparedStatement.setString(8, roomType);
            preparedStatement.setString(9, foodIncluded);
            preparedStatement.setString(10, description);
            preparedStatement.setDouble(11, totalPrice);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                // Display a success message or perform other actions
                System.out.println("Booking saved successfully!");
                JOptionPane.showMessageDialog(this, "Your package has been booked!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Display a failure message or perform other actions
                System.out.println("Booking could not be saved.");
                JOptionPane.showMessageDialog(this, "Booking failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public boolean validatedetails() {
        String departureDate = depart.getText();
        String returnDate = returndate.getText();
        //int travelers = Integer.parseInt(nooftravellers.getText());
        String nooftravellersText = String.valueOf(nooftravellers);
        boolean isdeparturedateValid = validateDepartureDate(departureDate);
        if (!isdeparturedateValid) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use a valid date format (e.g., yyyy-mm-dd)", "Date Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        boolean isreturndateValid = validateReturnDate(returnDate);
        if (!isreturndateValid) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use a valid date format (e.g., yyyy-mm-dd)", "Date Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        boolean isTravelersValid = validateNumberOfTravellers(nooftravellersText, numberPattern);
        if (!isTravelersValid) {
            JOptionPane.showMessageDialog(this, "Invalid number of travelers entered. Please use numbers.", "Traveler Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;

    }

    public int updateBookingInfo(int personalInfoId) {
        String packageYesNo = jRadioButton3.isSelected() ? "yes" : "no";
        String departureDate = depart.getText();
        String returnDate = returndate.getText();
        int daysStay = Integer.parseInt(jLabel23.getText());
        travelers = Integer.parseInt(nooftravellers.getText());
        String roomType = jRadioButton7.isSelected() ? "ac" : "non ac";
        String foodIncluded = jRadioButton5.isSelected() ? "yes" : "no";
        double totalPrice = Double.parseDouble(jLabel21.getText());

        validatedetails();

        String jdbcUrl = "jdbc:mysql://localhost:3306/touristsmangementsystem";

        String username = "root";
        String password = "Mahanoor@2003";

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            String query = "UPDATE booking_info SET packageYES=?, departuredate=?, returndate=?, numofdays=?, numoftravelers=?, bookedtravellers=?, roomtype=?, foodincluded=?, description=?, totalprice=? WHERE ID=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, packageYesNo);
            preparedStatement.setString(2, departureDate);
            preparedStatement.setString(3, returnDate);
            preparedStatement.setInt(4, daysStay);
            preparedStatement.setInt(5, travelers);
            preparedStatement.setInt(6, bookedtravellers); // You may need to set this variable
            preparedStatement.setString(7, roomType);
            preparedStatement.setString(8, foodIncluded);
            preparedStatement.setString(9, description); // You may need to set this variable
            preparedStatement.setDouble(10, totalPrice);
            preparedStatement.setInt(11, personalInfoId); // Assuming personalInfoId is the ID of the record to be updated
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                // Display a success message or perform other actions
                System.out.println("Booking updated successfully!");
                JOptionPane.showMessageDialog(this, "Your booking has been updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
            } else {
                // Display a failure message or perform other actions
                System.out.println("Booking update failed.");
                JOptionPane.showMessageDialog(this, "Booking update failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return personalInfoId;
    }

    public void showUpdateButton() {
        update.setVisible(true);
        add1.setVisible(false);
    }
    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        showUpdateButton();
        updateBookingInfo(personalInfoId);

    }//GEN-LAST:event_updateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        generatebill g = new generatebill(personalInfoId);
        g.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed

    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed

    }//GEN-LAST:event_jRadioButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Booking_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Booking_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Booking_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Booking_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int personalInfoId = savePersonalInfo(); // Replace with the actual method name if different
                Booking_Info bookingForm = new Booking_Info(personalInfoId);
                bookingForm.setVisible(true);
            }

            private int savePersonalInfo() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add1;
    private javax.swing.JTextField depart;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JTextField nooftravellers;
    private javax.swing.JTextField returndate;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
